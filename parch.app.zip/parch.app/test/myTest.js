function sum(a, b) {
  return a + b;
}

function restar(a,b) {
  return a - b
}
module.exports = {sum, restar}